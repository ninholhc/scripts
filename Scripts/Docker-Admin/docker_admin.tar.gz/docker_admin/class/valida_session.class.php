<?php
session_start();
require_once(dirname(__FILE__) . '/../conf/config.php');
require_once(PROJETO . '/class/json.class.php');

Class Logado{

  public $login;
  public $usuario;
  public $id;
  public $lvl;

  function __construct(){

    $this->id = false;
    $campos = array("login","json_id");
  	$json = new json(PROJETO . '/db/users.json');
  	$json->select($campos);

    while($json->readnext()){
  		if($_SESSION['id']  == $json->retorno['json_id']){
        $this->login = $json->retorno['login'];
        $this->usuario = $json->retorno['usuario'];
        $this->id = $json->retorno['json_id'];
        $this->lvl = $json->retorno['level'];
  		}
  	}
    if(isset($this->id)){
      return true;
    }else{
      return false;
    }

  }
}
?>
