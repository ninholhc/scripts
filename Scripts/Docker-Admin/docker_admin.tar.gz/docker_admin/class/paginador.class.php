<?php
class paginator{
	private $pags;
	private $regs;
	private $regspag;
	private $funcao;
	//construtor default
	function __construct($pags, $regs, $regspag){
		$this->pags = $pags;
		$this->regs = $regs;
		$this->regspag = $regspag;
	}

	function inipag(){
		echo '<div align="center">';
	}
	function fimpag(){
		echo '</div>';
	}

	function imppag(){
		//define total de páginas
		if (($this->regs % $this->regspag) == 0){
			$totpag = $this->regs / $this->regspag;
		} else {
			$totpag = ((int)($this->regs / $this->regspag)) + 1;
		}
		//define a primeira e ultima pagina a ser exibida
		if ($totpag <= 10){
			$pripag = 1;
			$ultpag = $totpag;
		} else {
			if($this->pags <= 5){
				$pripag = 1;
				$ultpag = 10;
			} else {
				if(($this->pags + 5) < $totpag){
					$pripag = ($this->pags - 4);
					$ultpag = ($this->pags + 5);
				}else{
					$pripag = ($totpag - 9);
					$ultpag = $totpag;
				}
			}
		}
		//seta para primeira página
		echo "<table><tr><td><a href='javascript:{$this->funcao}(1)' style='color: #000000;font-weight: bold;font-size: 20px;'>|&lArr;</a>&ensp;</td>";
		//cria primeiro retrocesso
		if($this->pags > 1){
			$imppag = $this->pags - 1;
			echo "<td><a href='javascript:{$this->funcao}({$imppag})' style='color: #000000;font-weight: bold;font-size: 20px;'>&lArr;</a></td>";
		} else {
			echo "<td><a href='javascript:{$this->funcao}(1)' style='color: #000000;font-weight: bold;font-size: 20px;'>&lArr;</a></td>";
		}
		//laço criando links
		for($i=$pripag; $i<=$ultpag; $i++){
			if ($i == $this->pags){
				echo "<td>&ensp;<a href='javascript:{$this->funcao}({$i})' style='color: #000000;font-weight: bold;font-size: 20px;'><b>{$i}</b></a>&ensp;</td>";
			}else{
				echo "<td>&ensp;<a href='javascript:{$this->funcao}({$i})' style='color: #000000;'font-weight: bold;font-size: 20px;'><b>{$i}</b></a>&ensp;</td>";
			}
		}
		//cria avanço
		if($this->pags < $ultpag){
			$imppag = $this->pags + 1;
			echo "<td><a href='javascript:{$this->funcao}({$imppag})' style='color: #000000;font-weight: bold;font-size: 20px;'>&rArr;</a>&ensp;</td>";
		} else {
			echo "<td><a href='javascript:{$this->funcao}({$ultpag})' style='color: #000000;font-weight: bold;font-size: 20px;'>&rArr;</a>&ensp;</td>";
		}
		//seta última página
		echo "<td><a href='javascript:{$this->funcao}({$totpag})' style='color: #000000;font-weight: bold;font-size: 20px;'>&rArr;|</a></td></table>";
	}

	function gerpag($funcao){
		$this->funcao = $funcao;
		$this->inipag();
		$this->imppag();
		$this->fimpag();
	}
}
?>
