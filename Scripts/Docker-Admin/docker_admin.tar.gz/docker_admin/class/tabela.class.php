<?php

class novatabela{
	private $cab;
	private $width;
	public  $out;
	private $saida;
	//construtor default
	function __construct($cabs,$width = null,$saida = 1){
		$this->cab = $cabs;
		$this->width = $width;
		$this->out = '';
		$this->saida = $saida;
	}

	function tableini(){
		if($this->width != null){
			if($this->saida == 1){
					echo '<table border="1" class="lista" style="width:'.$this->width.'">';
			}else{
				$this->out = $this->out . '<table border="1" class="lista" style="width:'.$this->width.'">';
			}
		}else{
			if($this->saida == 1){
				echo '<table border="1" class="lista">';
			}else{
				$this->out = $this->out . '<table border="1" class="lista">';
			}
		}

	}

	function theadini(){
		if($this->saida == 1){
			echo '<thead style="background-color: #B5EFC0"><tr>';
		}else{
			$this->out = $this->out . '<thead style="background-color: #B5EFC0"><tr>';
		}
	}

	function theadfim(){
		if($this->saida == 1){
			echo '</tr></thead>';
		}else{
			$this->out = $this->out . '</tr></thead>';
		}
	}

	function tbodyini(){
		if($this->saida== 1){
			echo '<tbody style="background-color: #CEE3D2;font-style: italic;font-weight: bold;font-size: medium;">';
		}else{
			$this->out = $this->out . '<tbody style="background-color: #CEE3D2;font-style: italic;font-weight: bold;font-size: medium;">';
		}
	}

	function tbodyfim(){
		if($this->saida == 1){
			echo '</tbody>';
		}else{
			$this->out = $this->out . '</tbody>';
		}
	}

	function tablefim(){
		if($this->saida == 1){
			echo '</tbody></table>';
		}else{
			$this->out = $this->out . '</tbody></table>';
		}
	}

	function cabecalho(){
		foreach ($this->cab as $cab){
			if(is_array($cab)){
				if($this->saida == 1){
					echo '<th style="width:'.$cab[1].'">' . $cab[0] . "</th>";
				}else{
					$this->out = $this->out . '<th style="width:'.$cab[1].'">' . $cab[0] . "</th>";
				}
			}else{
				if($this->saida == 1){
					echo "<th>" . $cab . "</th>";
				}else{
					$this->out = $this->out . "<th>" . $cab . "</th>";
				}
			}
		}
	}

	function item($itms, $id = null){
		if (!$id){
			if($this->saida == 1){
				echo "<tr>";
			}else{
				$this->out = $this->out . "<tr>";
			}
		} else {
			if($this->saida == 1){
				echo '<tr id="' . $id . '">';
			}else{
				$this->out = $this->out . '<tr id="' . $id . '">';
			}
		}

		foreach ($itms as $itm){
			if(!is_array($itm)){
				if($this->saida == 1){
					echo '<td style="padding: 5px;">' . $itm . '</td>';
				}else{
					$this->out = $this->out . '<td style="padding: 5px;">' . $itm . '</td>';
				}
				continue;
			}
			if ($itm['tipo'] == 'texto'){
				if($this->saida == 1){

				}else{

				}
				echo "<td>" . $itm['vlr'] . "</td>";
			} else {
				if ($itm['btn'] == ''){
					$botao = 'btn-default';
				}else{
					$botao = $itm['btn'];
				}
				if($this->saida == 1){
					echo '<td align="center">
					<button type="button" class="btn '.$botao.' btn-xs" onclick="'.$itm['funcao'].'">
					<span class="glyphicon '.$itm['img'].'"></span>  '.$itm['vlr'].'</button>
					</td>';
				}else{
					$this->out = $this->out . '<td align="center">
					<button type="button" class="btn '.$botao.' btn-xs" onclick="'.$itm['funcao'].'">
					<span class="glyphicon '.$itm['img'].'"></span>  '.$itm['vlr'].'</button>
					</td>';
				}
			}
		}
		if($this->saida == 1){
			echo "</tr>";
		}else{
			$this->out = $this->out . "</tr>";
		}
	}

	function initable(){
		$this->tableini();
		$this->theadini();
		$this->cabecalho();
		$this->theadfim();
		$this->tbodyini();
	}

	function fimtable(){
		$this->tbodyfim();
		$this->tablefim();
	}
}
?>
