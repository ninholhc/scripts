<?php
require_once(dirname(__FILE__) . '/../conf/config.php');
require_once(PROJETO.'/class/novasql.postgre.class.php');

class estados{

	function __construct(){}

	function getEstado($estado_id = ''){

    $conexao = pg_connect("host=".PGHOST." port=".PGPORT." dbname=".PGBASE." user=".PGUSER." password=".PGPASS);

		$sql = new novasql('cadastro','unidade_federativa',$conexao);
	  if(empty($estado_id)){
			$sql->select( array('id','unidade'),null);
			$estados[0] = "SELECIONE";
			while ($sql->readnext()) {
				$estados[$sql->sqlretorno['id']] = $sql->sqlretorno['unidade'];
			}
			return $estados;
		}else{
			$sql->select( array('unidade'),array('id'=>$estado_id));
			$sql->readnext();
			return $sql->sqlretorno['unidade'];
		}

		pg_close($conexao);
	}
}
?>
