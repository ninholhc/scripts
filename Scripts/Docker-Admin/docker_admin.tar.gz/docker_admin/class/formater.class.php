<?php

class formater{

	function __construct(){}

	function cpfcnpj($cpf_cnpj){
		$cpf_cnpj = preg_replace("/[^0-9]/", "", $cpf_cnpj);
    $tipo_dado = NULL;
    if(strlen($cpf_cnpj)==11){
        $tipo_dado = "cpf";
    }
    if(strlen($cpf_cnpj)==14){
        $tipo_dado = "cnpj";
    }
    switch($tipo_dado){
        default:
            $cpf_cnpj_formatado = "";
        break;

        case "cpf":
            $bloco_1 = substr($cpf_cnpj,0,3);
            $bloco_2 = substr($cpf_cnpj,3,3);
            $bloco_3 = substr($cpf_cnpj,6,3);
            $dig_verificador = substr($cpf_cnpj,-2);
            $cpf_cnpj_formatado = $bloco_1.".".$bloco_2.".".$bloco_3."-".$dig_verificador;
        break;

        case "cnpj":
            $bloco_1 = substr($cpf_cnpj,0,2);
            $bloco_2 = substr($cpf_cnpj,2,3);
            $bloco_3 = substr($cpf_cnpj,5,3);
            $bloco_4 = substr($cpf_cnpj,8,4);
            $digito_verificador = substr($cpf_cnpj,-2);
            $cpf_cnpj_formatado = $bloco_1.".".$bloco_2.".".$bloco_3."/".$bloco_4."-".$digito_verificador;
        break;
    }
    return $cpf_cnpj_formatado;
	}

	function telefone($numero){

		$numero = preg_replace("/[^0-9]/", "", $numero);
    $tipo_dado = NULL;
    if(strlen($numero)==7){
        $tipo_dado = "sdd";
    }
    if(strlen($numero)==9){
        $tipo_dado = "cdd";
    }
		if(strlen($numero)==10){
        $tipo_dado = "cel";
    }
		if(strlen($numero)==11){
        $tipo_dado = "dcel";
    }

		switch($tipo_dado){
        default:
            $numero_formatado = "";
        break;
        case "sdd":
            $bloco_1 = substr($numero,0,3);
            $bloco_2 = substr($numero,3,4);
            $numero_formatado = $bloco_1."-".$bloco_2;
        break;
				case "cdd":
            $bloco_1 = substr($numero,0,2);
            $bloco_2 = substr($numero,2,3);
            $bloco_3 = substr($numero,5,4);
            $numero_formatado = "(".$bloco_1.")".$bloco_2."-".$bloco_3;
        break;
				case "cel":
						$bloco_1 = substr($numero,0,2);
						$bloco_2 = substr($numero,2,4);
						$bloco_3 = substr($numero,6,4);
						$numero_formatado = "(".$bloco_1.")".$bloco_2."-".$bloco_3;
        break;
				case "dcel":
						$bloco_1 = substr($numero,0,2);
						$bloco_2 = substr($numero,2,5);
						$bloco_3 = substr($numero,7,4);
						$numero_formatado = "(".$bloco_1.")".$bloco_2."-".$bloco_3;
        break;
    }

	     return $numero_formatado;
		 }


		 function money($money){
			 return number_format($money, 2, ',', '.');
		 }

		 function cep($cep){
			 $cep = substr($cep, 0, 5) . '-' . substr($cep, 5, 3);
			 return $cep;
		 }

		 function insce($insce){
			 $insce = substr($insce, 0, 3) . '.' .substr($insce, 3, 3) . '.' . substr($insce, 6, 3). '.' . substr($insce, 9, 3);
			 return $insce;
		 }

		 function inscm($inscm){
			 $inscm = substr($inscm, 0, 6) . '-' .substr($inscm, 6, 1);
			 return $inscm;
		 }
}

?>
