//TELEFONE
var telefoneMask = function (val) {
   return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
},
telefoneOpts = {
  onKeyPress: function(val, e, field, options) {
    field.mask(telefoneMask.apply({}, arguments), options);
  }
};


//CEP
var cepMask = function (val) {
	return val.replace(/\D/g, '').length <= 7 ? '00000-009' : '00000-000';
},
cepOpts = {
  onKeyPress: function(val, e, field, options) {
  field.mask(cepMask.apply({}, arguments), options);
}
};


// Mascara de CPF e CNPJ
var cpfcnpjMask = function (val) {
  return val.replace(/\D/g, '').length <= 11 ? '000.000.000-009' : '00.000.000/0000-00';
},
cpfcnpjOpts = {
  onKeyPress: function(val, e, field, options) {
    field.mask(cpfcnpjMask.apply({}, arguments), options);
  }
};

// Mascara de inscricao
var inscestMask = function (val) {
  return val.replace(/\D/g, '').length <= 15 ? '000.000.000.009' : '00.000.000.000';
},
inscestOpts = {
  onKeyPress: function(val, e, field, options) {
    field.mask(inscestMask.apply({}, arguments), options);
  }
};
var inscmuniMask = function (val) {
  return val.replace(/\D/g, '').length <= 9 ? '0000000-9' : '0000000-0';
},
inscmuniOpts = {
  onKeyPress: function(val, e, field, options) {
    field.mask(inscmuniMask.apply({}, arguments), options);
  }
};
