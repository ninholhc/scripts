#!/bin/bash
useradd -m ubuntu
echo "ubuntu:ubuntu" | chpasswd
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y ssh sudo
echo 'ubuntu  ALL=(ALL) NOPASSWD:ALL' | sudo EDITOR='tee -a' visudo
/etc/init.d/ssh restart
