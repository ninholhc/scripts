<?php
session_start();
require_once(dirname(__FILE__) . '/conf/config.php');
require_once(PROJETO . '/class/form.class.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/valida_session.class.php');

$logado = new Logado();
if($logado == false){
  header("Location: " . SIS);
  exit();
}

if(isset($_POST['login']) OR isset($_POST['senha'])){

	$campos = array("login","senha","json_id");

	$json = new json(PROJETO . '/db/users.json');
	$json->select($campos);

	while($json->readnext()){
		if($json->retorno['login'] == $_POST['login']){
			if($json->retorno['senha'] == sha1($_POST['senha'])){
				$_SESSION['id'] = $json->retorno['json_id'];
				$_SESSION['logado'] = 1;
				header('Location: ' . MAIN);
				exit;
			} else {
				$_SESSION['result'] = "<div id=\"ocultar\">SENHA INCORRETA</div>";
				$_SESSION['logado'] = 0;
				header("Location: " . SIS);
				exit;
			}
		}
	}

	$_SESSION['result'] = "<div id=\"ocultar\">USUÁRIO " . $_POST['login'] . " NÃO CADASTRADO</div>";
	if (!isset($_SESSION['logado'])) {
  	$_SESSION['logado'] = 0;
	}
	header('Location: ' . SIS);
	exit;
}

if (isset($_SESSION['logado']) AND $_SESSION['logado'] === 1){
	header('Location: ' . MAIN);
	exit;
}

$form = new form("index.php");
$form->addText('login','Usuário:', '', 30,45,1,90);
$form->addPassword('senha','Senha:','',30,45,1,90);
$form->addSubmit('Login');

echo "<html>
<head>
<title>DOCKER ADMIN</title>
<link rel=\"stylesheet\" type=\"text/css\" href=\"css/styles.css\">
</head>
<script type=\"text/javascript\">
setTimeout(function(){var a = document.getElementById(\"ocultar\");a.style=\"display:none\"}, 5000);
</script>
<body align=\"center\">
<br>
<div>
<fieldset style=\"width:450px;margin:auto;border-radius: 8px;border: 1px #000000 solid;\">
<table>
";

$form->formPrint();

echo "<div align=\"center\"><table>";
if (isset($_SESSION['result'])){
	echo $_SESSION['result'];
	unset($_SESSION['result']);
}
echo "</table>
</fielset>
</div>
</body>
</html>";

?>
