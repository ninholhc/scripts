<?php
require_once(dirname(__FILE__) . '/conf/config.php');
session_start();
$_SESSION['logado'] = 0;
header('Location: ' . SIS);
exit;
?>
