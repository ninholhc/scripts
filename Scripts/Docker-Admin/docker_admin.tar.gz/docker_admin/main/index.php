<?php
require_once(dirname(__FILE__) . '/../conf/config.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/valida_session.class.php');
$logado = new Logado();
if($logado == false){
  header("Location: " . SIS);
}
?>
<html>
<head>
<?php
echo "<html>
<head>
<title>DOCKER ADMIN</title>
<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/styles.css\">
</head>
<br>
<p>OLÁ " . $logado->usuario .'</p>';
echo "<table align=\"center\"><tr>";
if($logado->lvl == 2){
    echo "<td style=\"width: 150px;text-align: center;vertical-align: middle;\"><a href=\"admin\"><div><img src=\"../img/admin.png\" width=\"45\" height=\"45\"></div><br><div><b>ADMIN</b></div></a></td>";
}
echo "<td style=\"width: 150px;text-align: center;vertical-align: middle;\"><a href=\"docker\"><div><img src=\"../img/docker.png\" width=\"45\" height=\"45\"></div><br><div><b>DOCKER</b</div></a></td>
      <td style=\"width: 150px;text-align: center;vertical-align: middle;\"><a href=\"../logout.php\"><div><img src=\"../img/exit.png\" width=\"45\" height=\"45\"></div><br><div><b>SAIR</b></div></a></td>";
echo '</tr></table>';


?>
</div>
<style type="text/css">
body {
	background-color: #18acdc;
	margin:0px;
	text-align:center;
	font-weight: bold;
}
#cab {
  display: table;
  margin: 0 auto;
}
</style>
</html>
