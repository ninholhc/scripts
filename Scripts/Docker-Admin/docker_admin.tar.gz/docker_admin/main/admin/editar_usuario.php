<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/valida_session.class.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/form.class.php');

$logado = new Logado();
if($logado == false){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}
if($logado->lvl < 2){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
  $post = true;
}else{
  $post = false;
}

if(isset($_GET['id']) AND $post){

  if(empty($_POST['usuario'])){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>DEFINA NOME DE USUÁRIO<br></b></div>";
    exit();
  }

  $json = new json(PROJETO . '/db/users.json');
  $campos = array("login","senha");
  $json->select($campos);

  while ($json->readnext()) {
    if($_GET['id'] == $json->retorno['json_id']){
      $update['login'] = $json->retorno['login'];
      $update['senha'] = $json->retorno['senha'];
      $update['json_id'] = $json->retorno['json_id'];
      $id = $json->retorno['json_id'];
    }
  }
  $update['usuario'] = $_POST['usuario'];
  $update['level'] = $_POST['level'];
  $json->update($update,$id);
  echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>USUÁRIO ATUALIZADO<br></b></div>";
  exit();

}

$json = new json(PROJETO . '/db/users.json');
$campos = array("usuario");

$json->select($campos);

while ($json->readnext()) {
  if($_GET['id'] == $json->retorno['json_id']){
    $id = $json->retorno['json_id'];
    $usuario = $json->retorno['usuario'];
    $level = $json->retorno['level'];
  }
}

?>
<div align="center">
<?php
$form = new form("editar_usuario.php?id=" . $_GET['id'] . "");
$form->fieldsetOpen('EDITAR USUÁRIO','400px;','#000000;','#B5EFC0;');
$form->fieldsetOpen('','350px;','','#B5EFC0;','none;');
$form->formIni();
$form->addText('usuario','USUÁRIO NOME:', $usuario, 20,45,2,110);
$levels = array(1=>'Usuário',2=>'Administrador');
$form->addSelect('level','LEVEL:',$levels,$level,1,60);

$form->exibir($form->campos[0]);
$form->exibir($form->campos[1]);

$form->fieldsetClose();

$form->addSubmit('SALVAR',2);
$form->addButtonGet('ALTERAR SENHA','javascript:carregar(\'alterar_senha.php?id='. $id .'\')',3);
$form->addButtonGet('VOLTAR',"javascript:carregar('list_usuario.php')",4);

$cnt = 2;
while ($cnt <= 4) {
  $form->exibir($form->campos[$cnt]);
  $cnt++;
}

$form->divId('resposta');
$form->fieldsetClose();
?>
</div>
<script type="text/javascript">
    $(document).ready(function(){
      $('#resposta').hide();
      $('#form1').ajaxForm({
        target: '#resposta',
        success: function(retorno){
          $('#resposta').html(retorno);
          $('#resposta').show();
        }
      })
    });
  </script>
