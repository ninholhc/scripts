<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/valida_session.class.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/form.class.php');

$logado = new Logado();
if($logado == false){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}
if($logado->lvl < 2){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}


if(($_SERVER['REQUEST_METHOD']) == 'POST'){

  if($_POST['senha1'] != $_POST['senha2']){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>SENHAS NÃO SÃO IGUAIS<br></b></div>";
    exit();
  }

  $json = new json(PROJETO . '/db/users.json');
  $campos = array("login","senha");
  $json->select($campos);

  while ($json->readnext()) {
    if($_GET['id'] == $json->retorno['json_id']){
      $update['login'] = $json->retorno['login'];
      $update['senha'] = sha1($_POST['senha1']);
      $update['usuario'] = $json->retorno['usuario'];
      $update['json_id'] = $json->retorno['json_id'];
      $id = $json->retorno['json_id'];
    }
  }
  $json->update($update,$id);
  echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);form1.reset();</script><b>SENHA ATUALIZADA<br></b></div>";
  exit();
}

$json = new json(PROJETO . '/db/users.json');
$campos = array("usuario");
$json->select($campos);

while ($json->readnext()) {
  if($_GET['id'] == $json->retorno['json_id']){
    $usuario = $json->retorno['usuario'];
  }
}
?>
<div align="center">
<?php
$form = new form("alterar_senha.php?id=" . $_GET['id']."");
$form->fieldsetOpen('ALTERAR SENHA','500px;','#000000;','#B5EFC0;');
$form->fieldsetOpen('','450px;','','#B5EFC0;','none;');
$form->addSimpleText('USUÁRIO:' . $usuario);
$form->formIni();
$form->addPassword('senha1','SENHA:', '', 20,45,1,110);
$form->addPassword('senha2','REPITA A SENHA:', '',20,45,1,110);

$form->exibir($form->campos[0]);
$form->exibir($form->campos[1]);
$form->fieldsetClose();

$form->addButtonOnclick('SALVAR','alterar_senha.php?id='.  $_GET['id'] .'',2);
$form->addButtonGet('VOLTAR',"javascript:carregar('editar_usuario.php?id=". $_GET['id']."')",4);

$form->exibir($form->campos[2]);
$form->exibir($form->campos[3]);

$form->formFim();
$form->divId('resposta');
$form->fieldsetClose();
?>
</div>
<script type="text/javascript">
    $(document).ready(function(){
      $('#resposta').hide();
      $('#form1').ajaxForm({
        target: '#resposta',
        success: function(retorno){
          $('#resposta').html(retorno);
          $('#resposta').show();
        }
      })
    });
</script>
