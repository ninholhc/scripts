<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/tabela.class.php');

echo '<br><script type="text/javascript">document.title = "LISTA USUARIO";</script><div align="center"><button onclick="novo_usuario()">NOVO USUARIO</button></div><br>';

if(isset($_GET['msg'])){
  echo "<div id='ocultar'>
  <script type='text/javascript'>
  setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 8000);
  document.getElementById('form1').reset();</script>
  <b>USUARIO CADASTRADO!</b>
  </div>";
}

$campos = array("login","usuario");
$json = new json(PROJETO . '/db/users.json');
$json->select($campos);
$cab = false;

while ($json->readnext()) {
  if(!$cab){
    $tabela = new novatabela(array(array('Login','150px'),array('Usuário','150px'),array('Editar','50px')));
    echo '<br><div align="center">';
    $tabela->initable();
    $cab = true;
  }

  $user['login'] = $json->retorno['login'];
  $user['usuario'] = $json->retorno['usuario'];
  $user['json_id'] = '<div align="center"><button onclick="editar_usuario('.$json->retorno['json_id'].')"><img src="../../img/editar.png" width="20" height="20"></button></div>';

  $tabela->item($user);
}

$tabela->fimtable();
echo '</div><br>';
?>
<script type="text/javascript">
function editar_usuario(id,pag) {
  $( "#conteudo" ).load( 'editar_usuario.php?id=' + id);
}

function novo_usuario() {
  $( "#conteudo" ).load( 'novo_usuario.php' );
}
</script>
