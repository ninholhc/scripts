<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
	<title>ADMINIISTRAÇÃO</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="stylesheet" href="../../css/menu.css" media="screen" type="text/css">
	<link rel="stylesheet" href="../../css/menu-item.css" media="screen" type="text/css">
	<link rel="stylesheet" href="../../css/menu-bar.css" media="screen" type="text/css">
	<link rel="stylesheet" href="../../css/tabs.css" media="screen" type="text/css">
	<script type="text/javascript" src="../../js/menu-for-applications.js"></script>
	<script type="text/javascript" src="../../js/prototype.js" ></script>
  <script type="text/javascript" src="../../js/scriptaculous.js" ></script>
	<script type="text/javascript" src="../../js/jquery.min.js" ></script>
	<script type="text/javascript" src="../../js/jquery.mask.js" ></script>
	<script type="text/javascript" src="../../js/jquery.form.min.js" ></script>
	<script type="text/javascript" src="../../js/bootstrap.min.js" ></script>
	<script type="text/javascript" src="../../js/livepipe.js"></script>
	<script type="text/javascript" src="../../js/tabs.js"></script>
	<script type="text/javascript" src="../../js/default.mask.js"></script>
	<script type="text/javascript" src="../../js/open.tabs.js"></script>
</head>

<style type="text/css">
body{
	margin:0px;
	text-align:center;
}

#mainContentainer{
	width:760px;
	margin:0 auto;
	text-align:left;
}
#mainContent{
	border:1px solid #000;
}

#textContent{
	height:400px;
	overflow:auto;
	padding-left:5px;
	padding-right:5px;
}
#menuDiv{
	width:100%;
	overflow:hidden;
}
pre{
	color:#F00;
}
p,pre{

}
</style>

<div id="mainContentainer">
	<div id="MainContainer">
		<!-- This <ul><li> list is the source of a menuModel object -->
		<ul id="menuModel" style="display:none">
			<li id="50000"><a href="#" title="Usuários">ADMIN</a>
				<ul width="200">
				<li id="500001"><a href="javascript:carregar('novo_usuario.php')" title="Novo usuário">NOVO USUÁRIO</a></li>
				<li id="500002"><a href="javascript:carregar('list_usuario.php')" title="Visualizar empresas">VISUALIZAR USUÁRIOS</a></li>
				</ul>
			</li>
				<li id="50003" itemType="separator"></li>
			<li id="50007"><a href="../">VOLTAR</a></li>
		</ul>

</div></div>
<div id="menuDiv"></div>
<div id="conteudo"></div>

<script type="text/javascript">
	var menuModel = new DHTMLSuite.menuModel();
	menuModel.addItemsFromMarkup('menuModel');
	menuModel.setMainMenuGroupWidth(00);
	menuModel.init();

	var menuBar = new DHTMLSuite.menuBar();
	menuBar.addMenuItems(menuModel);
	menuBar.setTarget('menuDiv');

	menuBar.init();

	function carregar(url) {
  	$( "#conteudo" ).load( url );
	}

	document.observe('dom:loaded',function(){
			new Control.Tabs('tabs_example_one');
	});

</script>
