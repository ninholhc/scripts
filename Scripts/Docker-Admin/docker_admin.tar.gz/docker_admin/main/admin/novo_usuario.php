<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/valida_session.class.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/form.class.php');

$logado = new Logado();
if($logado == false){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}
if($logado->lvl < 2){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}

if(($_SERVER['REQUEST_METHOD']) == 'POST'){

  if(empty($_POST['login'])){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>DEFINA LOGIN<br></b></div>";
    exit();
  }

  if(empty($_POST['usuario'])){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>DEFINA NOME DO USUÁRIO<br></b></div>";
    exit();
  }

  if(empty($_POST['senha'])){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>DEFINA SENHA<br></b></div>";
    exit();
  }

  if(empty($_POST['senha2'])){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>REPITA A SENHA<br></b></div>";
    exit();
  }

  $campos = array("login");
	$json = new json(PROJETO . '/db/users.json');
	$json->select($campos);

  while ($json->readnext()) {
    if($_POST['login'] == $json->retorno['login']){
      echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>LOGIN JÁ EXISTE<br></b></div>";
      exit();
    }
  }

  if($_POST['senha'] != $_POST['senha2']){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>SENHAS NÃO SÃO IGUAIS<br></b></div>";
    exit();
  }

  $inserir = array('login'=>$_POST['login'],'senha'=>sha1($_POST['senha']),'usuario'=>$_POST['usuario'],'level'=>$_POST['level']);

  if($json->insert($inserir)){
    echo "<script type=\"text/javascript\">$('#conteudo').load('list_usuario.php?msg=1'); </script>";
  } else {
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>FALHA AO CADASTRAR USUÁRIO<br></b></div>";
  }
  exit();
}
?>
<div align="center">
<?php
$form = new form("novo_usuario.php");
$form->fieldsetOpen('NOVO USUÁRIO','500px;','#000000;','#B5EFC0;');
$form->fieldsetOpen('','450px;','','#B5EFC0;','none;');
$form->formIni();
$form->addText('login','USUÁRIO LOGIN:', '', 15,45,1,110);
$form->addText('usuario','USUÁRIO NOME:','',15,45,1,110);
$form->addPassword('senha', 'SENHA:', '', 32, 45,1,110,0);
$form->addPassword('senha2', 'REPITA A SENHA:', '', 32, 45,1,110,0);
$level = array(1=>'Usuário',2=>'Administrador');
$form->addSelect('level','LEVEL:',$level,'1',1,65);
$cnt = 0;
while ($cnt <= 4) {
  $form->exibir($form->campos[$cnt]);
  $cnt++;
}
$form->fieldsetClose();

$form->addSubmit('CADASTRAR');
$form->exibir($form->campos[5]);

$form->formFim();
$form->divId('resposta');
$form->fieldsetClose();
?>
</div>
<script type="text/javascript">
$(document).ready(function(){
  $('#resposta').hide();
  $('#form1').ajaxForm({
    target: '#resposta',
    success: function(retorno){
      $('#resposta').html(retorno);
      $('#resposta').show();
    }
  })
});
</script>
