<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/valida_session.class.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/form.class.php');

$logado = new Logado();
if($logado == false){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}
if($logado->lvl < 1){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}

if(($_SERVER['REQUEST_METHOD']) == 'POST'){

  if($_POST['container'] == '0'){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>SELECIONE O TIPO DE CONTAINER<br></b></div>";
    exit();
  }

  $output=null;
  $retval=null;
  exec("sudo docker image rm " . $_POST['container'],$output,$retval);

  if($retval == 1){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);carregar('remove_container.php?msg=1');</script></div>";
  }else{
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);carregar('remove_container.php?msg=0');</script></div>";
  }

  exit();
}
?>
<div align="center">
<?php
$lines = exec("sudo docker image ls | grep -v REPOSITORY | tr -s ' ' | cut -d ' ' -f 3 | wc --lines");

$name[0] = 'SELECIONE!';
$line = 1;
while ($line <= $lines) {
  $docker = exec("sudo docker image ls | grep -v REPOSITORY | tail -n " . $line . " | head -n 1 | tr -s ' ' | cut -d ' ' -f 1,2 | head -n 1 | sed 's| |:|g'");
  $image = exec("sudo docker image ls | grep -v REPOSITORY | tail -n " . $line . " | head -n 1 | tr -s ' ' | cut -d ' ' -f 3");
  $name[$image] = $docker;
  $line++;
}

$form = new form("remove_container.php");
$form->fieldsetOpen('REMOVER IMAGEM DE CONTAINER','550px;','#000000;','#B5EFC0;');
$form->fieldsetOpen('','500px;','','#B5EFC0;','none;');
$form->formIni();

$form->addSelect('container','IMAGEM:', $name, 0,1,110);

$form->exibir($form->campos[0]);

$form->fieldsetClose();

$form->addButtonAction('remove','<b>REMOVER</b>','remover();','Confirma a remoção da imagem?');
$form->exibir($form->campos[1]);

$form->formFim();
$form->divId('resposta');
if(isset($_GET['msg'])){
  switch ($_GET['msg']) {
    case '0':
      echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>IMAGEM REMOVIDA!<br></b></div>";
      break;
    case '1':
      echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>IMAGEM EM USO,NÃO É POSSÍVEL REMOVER<br></b></div>";
      break;
    default:
      break;
  }
}
$form->fieldsetClose();
?>
</div>
<script type="text/javascript">
$(document).ready(function(){
  $('#resposta').hide();
  $('#form1').ajaxForm({
    target: '#resposta',
    beforeSend: function() {
      $('#resposta').html('<img src="../../img/loader.gif" width="36" height="36"></img>');
      $('#resposta').show();
      $('button').prop('disabled', true);
      $('#container').prop('disabled', true);
    },
    success: function(){
      $('#resposta').html(retorno);
      $('#resposta').show();
      $('button').prop('disabled', false);
      $('#container').prop('disabled', false);
    }
  })
});

</script>
