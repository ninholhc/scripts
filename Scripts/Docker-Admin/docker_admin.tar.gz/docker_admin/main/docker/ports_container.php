<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/tabela.class.php');
echo '<br><fieldset style="border:0 none;"><legend align="center">';
echo exec("sudo docker container ls -a | grep -v 'CONTAINER ID' | grep '" . $_GET['img'] . "' | awk '{print \$NF}'");
echo '</legend>';

$json = new json(PROJETO . '/db/redirect.json');
$campos = array('docker','servidor_port','container_port');
$json->select($campos);
$cab = false;
while ($json->readnext()) {
	if(!$cab){
    $tabela = new novatabela(array(array('PORTA NO DOCKER ADMIN','300px'),array('PORTA NO CONTAINER','250px')));
    echo '<div align="center">';
    $tabela->initable();
    $cab = true;
  }

	if($json->retorno['docker'] == $_GET['img']){
		$tabela->item(array($json->retorno['servidor_port'],$json->retorno['container_port']));
	}

}
$tabela->fimtable();
echo '</div>';
?>
<style type="text/css">
body {
	background-color: #18acdc;
	margin:0px;
	text-align:center;
	font-weight: bold;
}
</style>
