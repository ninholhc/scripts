<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/valida_session.class.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/form.class.php');

$logado = new Logado();
if($logado == false){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}
if($logado->lvl < 1){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}

if(($_SERVER['REQUEST_METHOD']) == 'POST'){

  if(!is_dir(PROJETO . '/images/' . $_POST['imagem'])){
    mkdir(PROJETO . '/images/' . $_POST['imagem'],0777);
  }

  $nome = exec("sudo docker container ls -a | grep -v 'CONTAINER ID' | grep " . $_POST['imagem'] . " | awk '{print \$NF}'");
  $nome = PROJETO . '/images/' . $_POST['imagem'] . "/" . $nome . '_' . date("ymdHis") . '.tar';

  exec("sudo docker export " . $_POST['imagem'] . " > " . $nome);
  exec("chmod 777 " . $nome);

  echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);carregar('export_img.php?img=" . $_POST['imagem'] . "');</script><b>IMAGEM CRIADA<br></b></div>";

  exit();
}
?>
<br>
<button onclick="carregar('exec_container.php');"><b>VOLTAR</b></button>
<br>
<div align="center">
<?php
$name = exec("sudo docker container ls -a | grep -v 'CONTAINER ID' | grep " . $_GET['img'] . " | awk '{print \$NF}'");
$form = new form("export_img.php");
$form->fieldsetOpen('EXPORTAR CONTAINER ' . $name,'550px;','#000000;','#B5EFC0;');
$form->formIni();
$form->addHidden('imagem',$_GET['img']);
$form->addSubmit('GERAR IMAGEM');
$form->formPrint();
$form->formFim();
$form->divId('resposta');
$form->fieldsetClose();
?>
</div>
<div id="lista"></div>
<script type="text/javascript">
$(document).ready(function(){
  $('#resposta').hide();
  $('#form1').ajaxForm({
    target: '#resposta',
    beforeSend: function() {
      $('#resposta').html('<img src="../../img/loader.gif" width="36" height="36"></img>');
      $('#resposta').show();
      $('input[type="submit"]').prop('disabled', true);
    },
    success: function(retorno){
      $('#resposta').html(retorno);
      $('#resposta').show();
      $('input[type="submit"]').prop('disabled', false);

    }
  })
});

$("#lista").load('arquivos.php?imagem_id=<?php echo $_GET['img']; ?>');


</script>
