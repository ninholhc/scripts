<?php
session_cache_limiter('');
session_name('filemanager');
session_start();
unset_session($_SESSION['message']);
$_SESSION['status'] = "ok";
?>
