<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/valida_session.class.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/form.class.php');

function deleteAll($dir) {
  foreach(glob($dir . '/*') as $file) {
    if(is_dir($file)){
      deleteAll($file);
    }else{
      unlink($file);
    }
    rmdir($dir);
  }
}

$logado = new Logado();
if($logado == false){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}
if($logado->lvl < 1){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}

if(isset($_GET['remove'])){
  $up = exec("sudo docker container ls -a | grep -v 'CONTAINER ID' | grep '" . $_GET['remove'] . "' | awk '{print \$7'}");
  if($up != 'Exited'){
    exec("sudo docker kill " . $_GET['remove'] );
  }
  exec("sudo docker remove " . $_GET['remove'] );
  $json = new json(PROJETO . '/db/redirect.json');
  $campos = array('docker','servidor_port','container_port');
  $json->select($campos);
  while ($json->readnext()) {
    if($json->retorno['docker'] == $_GET['remove']){
      $id[] = $json->retorno['json_id'];
    }
  }
  $cnt = 0;
  foreach ($id as $value) {
    $json->delete($value - $cnt);
    $cnt++;
  }
  deleteAll(PROJETO ."/images/" . $_GET['remove']);
  exec("mv " . PROJETO ."/sftp/" . $_GET['remove'] . " /tmp");
  exit();
}

if(isset($_GET['stop'])){
  exec("sudo docker kill " . $_GET['stop'] );
  exit();
}

if(isset($_GET['start'])){
  exec("sudo docker start " . $_GET['start'] );
  exec("sudo docker exec -i " . $_GET['start'] . " ls /etc/init.d", $init);
  foreach ($init as $ini) {
    exec("sudo docker exec -i " . $_GET['start'] . "  /etc/init.d/" . $ini . " restart");
  }
  exit();
}

if(($_SERVER['REQUEST_METHOD']) == 'POST'){

  if(empty($_POST['nome'])){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>DEFINA NOME PARA O CONTAINER<br></b></div>";
    exit();
  }

  $tem = exec("sudo docker container ls -a | grep -v 'CONTAINER ID' | awk '{print \$NF'} | grep -w '" . $_POST['nome'] . "'");
  if(!empty($tem)){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>CONTAINER JÁ EXISTE<br></b></div>";
    exit();
  }

  if($_POST['container'] == '0'){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>SELECIONE O TIPO DE CONTAINER<br></b></div>";
    exit();
  }

  $port = '';
  if(!empty($_POST['servidor_port'])){
    $json = new json(PROJETO . '/db/redirect.json');
    $size = sizeof($_POST['servidor_port']);
    $servidor_port = $_POST['servidor_port'];
    $container_port = $_POST['container_port'];
    $cnt = 0;
    $equals = array();
    while($cnt < $size){
      if($json->select(array('servidor_port'=>$servidor_port[$cnt]))){
        echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>PORTA EM USO NO DOCKER ADMIN,SELECIONE OUTRA<br></b></div>";
        exit();
      }
      if($servidor_port[$cnt] < 50000 OR $servidor_port[$cnt] > 51000){
        echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>PORTA DO DOCKER ADMIN DEVE ESTAR ENTRE 50000 E 51000<br></b></div>";
        exit();
      }
      if(in_array($servidor_port[$cnt],$equals)){
        echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>VALOR DUPLICADO INFORMADO<br></b></div>";
        exit();
      }
      $equals[] = $servidor_port[$cnt];
      $port = $port . " -p " . $servidor_port[$cnt] . ":" .$container_port[$cnt];
      $cnt++;
    }
  }


  $output=null;
  $retval=null;
  $docker = exec("sudo docker run " . $port . " -d -t --name " . $_POST['nome'] . " " . $_POST['container'] . " /bin/bash",$output,$retval);
  if($retval != 0){
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>FALHA AO EXECUTAR CONTAINER<br></b></div>";
    exit();
  }

  if($_POST['ini'] == 1){
    exec("sudo docker cp " . PROJETO . "/scripts/initial.sh " . $docker . ":/tmp/initial.sh");
    exec("sudo docker exec -i " . $docker . "  /bin/bash /tmp/initial.sh");
  }

  $docker_id = exec("sudo docker container ls -a | grep -v 'CONTAINER ID' | grep -w '" . $_POST['nome'] . "' | awk '{print $1}'");
  $cnt = 0;
  while($cnt < $size){
    $json->insert(array('docker'=>$docker_id,'servidor_port'=>$servidor_port[$cnt],'container_port'=>$container_port[$cnt]));
    $cnt++;
  }

  echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);$('#lista').empty();$('#lista').load('exec_container_list.php');$('#nome').val('');$('#container').val('0');$('#ini').prop('checked', true);$('#redirect').empty();$.get('exec_container.php?start=" . $docker . "');</script><b>CONTAINER EM EXECUÇÃO<br></b></div>";
  exit();
}
?>
<div align="center">
<?php
$lines = exec("sudo docker image ls | grep -v REPOSITORY | tr -s ' ' | cut -d ' ' -f 3 | wc --lines");

$name[0] = 'SELECIONE!';
$line = 1;
while ($line <= $lines) {
  $docker = exec("sudo docker image ls | grep -v REPOSITORY | tail -n " . $line . " | head -n 1 | tr -s ' ' | cut -d ' ' -f 1,2 | head -n 1 | sed 's| |:|g'");
  $name[$docker] = $docker;
  $line++;
}

$form = new form("exec_container.php");
$form->fieldsetOpen('EXECUTAR CONTAINER','550px;','#000000;','#B5EFC0;');
$form->fieldsetOpen('','500px;','','#B5EFC0;','none;');
$form->formIni();
$form->addText('nome','NOME PARA A EXECUÇÃO:','',15,25,1,180);
$form->addSelect('container','IMAGEM:', $name, 0,1,110);
$form->addCheckbox('ini','Instalar ssh e sudo,para Ubuntu',1,1);
$form->addButtonOnclick('ADICIONAR REDIRECIONAMENTO','add_redirect();');

$form->exibir($form->campos[0]);
$form->exibir($form->campos[1]);
$form->exibir($form->campos[2]);
$form->exibir($form->campos[3]);
$form->divId('redirect');

$form->fieldsetClose();

$form->addSubmit('EXECUTAR');
$form->exibir($form->campos[4]);

$form->formFim();
$form->divId('resposta');
$form->fieldsetClose();
$form->divId('lista');
?>
</div>
<script type="text/javascript">
$(document).ready(function(){
  $('#resposta').hide();
  $('#form1').ajaxForm({
    target: '#resposta',
    beforeSend: function() {
      $('#resposta').html('<img src="../../img/loader.gif" width="36" height="36"></img>');
      $('#resposta').show();
      $('input[type="submit"]').prop('disabled', true);
      $("#nome").prop('disabled', true);
      $("#container").prop('disabled', true);
      $("#ini").prop('disabled', true);
      $(".container_port").prop('disabled', true);
      $(".servidor_port").prop('disabled', true);
    },
    success: function(retorno){
      $('#resposta').html(retorno);
      $('#resposta').show();
      $('input[type="submit"]').prop('disabled', false);
      $("#nome").prop('disabled', false);
      $("#container").prop('disabled', false);
      $("#ini").prop('disabled', false);
      $(".container_port").prop('disabled', false);
      $(".servidor_port").prop('disabled', false);
    }
  })
});

$('#ini').prop('checked', true);

$( "#lista" ).load('exec_container_list.php');

function reset_list(){
  $('#lista').empty();
  $('#lista').html('<img src="../../img/loader.gif" width="36" height="36"></img>');
}

function load_list(){
  $('#lista').empty();
  $('#lista').load('exec_container_list.php');
}

function aguardar(tempo){
    reset_list();
    var time = setInterval(function(){load_list(); clearInterval(time);}, tempo);
}

function remover_img(id) {
  if (confirm("Remover container?")) {
    $.get('exec_container.php?remove=' + id);
    aguardar(3000);
  }
}

function stop_img(id) {
  if (confirm("Parar container?")) {
    $.get('exec_container.php?stop=' + id);
    aguardar(3000);
  }
}

function start_img(id) {
  $.get('exec_container.php?start=' + id);
  aguardar(3000);
}

function add_redirect(){
  event.preventDefault();
  $("#redirect").prepend("<p>Porta no Docker admin:<input type='text' class='servidor_port' name='servidor_port[]' oninput=\"this.value=this.value.replace(/[^0-9]/g,'');\" maxlength='5' size='4'> Porta no Container:<input type='text' class='container_port' name='container_port[]' oninput=\"this.value=this.value.replace(/[^0-9]/g,'');\" maxlength='5' size='4'></p>");
}

function conectar_img(id) {
    var win = window.open('bash.php?container=' + id,'popup','width=900,height=700');
}

function view_ports(id){
      popUpObj=window.open("ports_container.php?img=" + id,"ModalPopUp","width=700," + "height=600");
			popUpObj.focus();
			LoadModalDiv();
}

function exportar(id){
  carregar('export_img.php?img=' + id);
}

function arquivos(id){
  carregar('dir_img.php?img=' + id);
}

</script>
