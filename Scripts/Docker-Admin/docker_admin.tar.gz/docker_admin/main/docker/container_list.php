<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/tabela.class.php');

$output=null;
$retval=null;
if(isset($_GET['remove'])){
  exec("sudo docker image rm " . $_GET['remove'],$output,$retval);
}

$result = exec("sudo docker image ls | grep -v 'REPOSITORY' | wc -l");
$cnt = 1;
$cab = false;
echo "<div align='center'><fieldset style='width:400px;background-color:#B5EFC0;border:2px solid;color:#000000;'><legend align='center'><b>Imagens</b></legend><div id='lista'>";

if($result > 0){
while ($cnt <= $result) {
  if(!$cab){
    $tabela = new novatabela(array(array('Imagem','250px'),array('Remover','50px')));
    echo '<br><div align="center">';
    $tabela->initable();
    $cab = true;
  }

  $linha = exec("sudo docker image ls | grep -v 'REPOSITORY' | tail -n " . $cnt . " | head -n 1 | awk '{print $1\":\"$2\"|\"\$3}'");
  $ped = explode('|',$linha);
  $cont['container'] = $ped[0];
  $cont['del'] = '<div align="center"><button onclick="rem_img(\''.$ped[1].'\')"><img src="../../img/delete.png" width="20" height="20"></button></div>';

  $tabela->item($cont);
  $cnt++;
}

$tabela->fimtable();
echo '</div>';
}
echo '<br></div>';
switch ($retval) {
  case 'null':
    break;
  case '0':
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>IMAGEM REMOVIDA!<br></b></div>";
    break;
  case '1':
    echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>IMAGEM EM USO,NÃO É POSSÍVEL REMOVER<br></b></div>";
    break;
  default:
    break;
}


echo '</fieldset></div>';
?>
<script type="text/javascript">

function rem_img(id) {
  if (confirm("Remover imagem?")) {
    carregar('container_list.php?remove=' + id);
  }
}

</script>
