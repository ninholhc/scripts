<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/valida_session.class.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/form.class.php');

$logado = new Logado();
if($logado == false){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}
if($logado->lvl < 1){
  echo "<script type='text/javascript'>$(location).prop('href', '" . SIS . "');</script>";
  exit();
}

if(($_SERVER['REQUEST_METHOD']) == 'POST'){

  if($_POST['type'] == '0'){
    if(empty($_POST['url_canal'])){
      echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>INFORME A URL DO CANAL<br></b></div>";
      exit();
    }

    if(exec("sudo docker pull " . $_POST['url_canal'])){
      echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);$('#form1').reload();</script><b>CANAL ADICIONADO<br></b></div>";
      exit();
    }else{
      echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>FALHA AO ADICIONAR CANAL<br></b></div>";
      exit();
    }
  }

  if($_POST['type'] == '1'){
    if(empty($_POST['nome'])){
      echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>INFORME NOME PARA IMAGEM<br></b></div>";
      exit();
    }

    if(empty($_POST['versao'])){
      echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>INFORME VERSÃO PARA IMAGEM<br></b></div>";
      exit();
    }

    if(isset($_FILES['docker_file'])) {
      $upload = $_FILES['docker_file']['tmp_name'];
      $arquivo = PROJETO . "/upload/" . $_FILES['docker_file']['name'];
      $upload = move_uploaded_file($upload, $arquivo);
      if($upload AND is_file($arquivo)){
        $nome = trim($_POST['nome']);
        $versao = trim($_POST['versao']);
        if(exec("sudo docker import " . $arquivo . " " . $nome . ":" . $versao . "")){
          echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);$('#docker_file').val('');$('#nome').val('');$('#versao').val('latest');</script><b>CONTAINER ADICIONADO<br></b></div>";
        }else{
          echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>FALHA AO ADICIONAR IMAGEM<br></b></div>";
        }
        unlink($arquivo);
      }else{
        echo "<div id='ocultar'><script type='text/javascript'>setTimeout(function(){var a = document.getElementById('ocultar');a.style='display:none'}, 6000);</script><b>FALHA NO UPLOAD DA IMAGEM<br></b></div>";
      }
    }
  }

  exit();
}
?>
<div align="center">
<?php
$type = 0;
if(isset($_GET['type'])){
  $type = $_GET['type'];
}
$form = new form("add_register.php");
$form->fieldsetOpen('ADICIONAR IMAGEM DE CONTAINER','550px;','#000000;','#B5EFC0;');

$form->addSelect('type','TIPO:',array(0=>'URL DE CANAL',1=>'DOCKER FILE'),$type);
$form->exibir($form->campos[0]);

if($type == 0){
  $form->fieldsetOpen('URL DE CANAL','600px;','#000000;','#B5EFC0;');
  $form->formIni();
  $form->addText('url_canal','URL DO CANAL:','',20,45,1,120);
  $form->exibir($form->campos[1]);
}

if($type == 1){
  $form->fieldsetOpen('DOCKER FILE','600px;','#000000;','#B5EFC0;');
  $form->formIni();
  $form->addText('nome','NOME PARA O CONTAINER:','',15,25,2,180);
  $form->addText('versao','VERSAO:','latest',4,8,4,'60');
  $form->addFile('docker_file','DOCKER FILE:');
  $form->exibir($form->campos[1]);
  $form->exibir($form->campos[2]);
  $form->exibir($form->campos[3]);
}

$form->fieldsetClose();

$form->addSubmit('ADICIONAR');
if($type == 0){
    $form->exibir($form->campos[2]);
}

if($type == 1){
    $form->exibir($form->campos[4]);
}

$form->formFim();
$form->divId('resposta');
$form->fieldsetClose();
?>
</div>
<script type="text/javascript">
$(document).ready(function(){
  $('#resposta').hide();
  $('#form1').ajaxForm({
    target: '#resposta',
    beforeSend: function() {
      $('#resposta').html('<img src="../../img/loader.gif" width="36" height="36"></img>');
      $('#resposta').show();
      $('input[type="submit"]').prop('disabled', true);
      $('#url_canal').prop('disabled', true);
      $('#nome').prop('disabled', true);
      $('#type').prop('disabled', true);
      $('#versao').prop('disabled', true);
      $('#docker_file').prop('disabled', true);
    },
    success: function(retorno){
      $('#resposta').html(retorno);
      $('#resposta').show();
      if ( $('#type').val() == 0 ) {
        $('#url_canal').val('');
      }
      if ( $('#type').val() == 1 ) {
        $('#nome').val('');
        $('#versao').val('latest');
        $('#docker_file').val('');
      }
      $('input[type="submit"]').prop('disabled', false);
      $('#url_canal').prop('disabled', false);
      $('#nome').prop('disabled', false);
      $('#type').prop('disabled', false);
      $('#versao').prop('disabled', false);
      $('#docker_file').prop('disabled', false);
    }
  })
});

$("#type").change(function(){
    carregar('add_register.php?type=' + $("#type").val());
});

</script>
