<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
require_once(PROJETO . '/class/json.class.php');
require_once(PROJETO . '/class/tabela.class.php');

$result = exec("sudo docker container ls -a | grep -v 'CONTAINER ID' | wc -l");
$cnt = 1;
$cab = false;
if($result < 1){
  exit();
}
while ($cnt <= $result) {
  if(!$cab){
    $tabela = new novatabela(array(array('Nome','150px'),array('Imagem','150px'),array('Endereço IP','150px'),array('Iniciar','50px'),array('Parar','50px'),
    array('SSH','50px'),array('Portas','50px'),array('Arquivos','50px'),array('Exportar','50px'),array('Remover','50px')));
    echo '<br><div align="center">';
    $tabela->initable();
    $cab = true;
  }

  $linha = exec("sudo docker container ls -a | grep -v 'CONTAINER ID' | tail -n " . $cnt . " | head -n 1 | awk '{print $2\"|\"\$NF\"|\"\$7\"|\"\$1}'");
  $ped = explode('|',$linha);
  if($ped[2] != 'Exited'){
    $linha = exec("sudo docker container ls -a | grep -v 'CONTAINER ID' | tail -n " . $cnt . " | head -n 1 | awk '{print $2\"|\"\$NF\"|\"\$8\"|\"\$1}'");
    $ped = explode('|',$linha);
  }
  $cont['imagem'] = $ped[1];
  $cont['nome'] = $ped[0];

  $cont['ip'] = exec("sudo docker container inspect " . $ped[3] . " | grep '\"IPAddress\":' | tail -n 1 | awk '{print $2}' | grep -E -o '([0-9]{1,3}[\.]){3}[0-9]{1,3}'");

  if($ped[2] == 'Exited'){
    $cont['start'] = '<div align="center"><button onclick="start_img(\''.$ped[3].'\')"><img src="../../img/start.png" width="20" height="20"></button></div>';
    $cont['stop'] = '<div></div>';
    $cont['con'] = '';
    $cont['view'] = '<div align="center"><button onclick="view_ports(\''.$ped[3].'\')"><img src="../../img/view.png" width="20" height="20"></button></div>';
    $cont['arquivos'] = '';
    $cont['export'] = '<div align="center"><button onclick="exportar(\''.$ped[3].'\')"><img src="../../img/export.png" width="20" height="20"></button></div>';
    $cont['del'] = '<div align="center"><button onclick="remover_img(\''.$ped[3].'\')"><img src="../../img/delete.png" width="20" height="20"></button></div>';
  }else{
    $cont['start'] = '<div></div>';
    $cont['stop'] = '<div align="center"><button onclick="stop_img(\''.$ped[3].'\')"><img src="../../img/stop.png" width="20" height="20"></button></div>';
    $cont['con'] = '<div align="center"><button onclick="conectar_img(\''.$ped[3].'\')"><img src="../../img/terminal.png" width="20" height="20"></button></div>';
    $cont['view'] = '<div align="center"><button onclick="view_ports(\''.$ped[3].'\')"><img src="../../img/view.png" width="20" height="20"></button></div>';
    $cont['arquivos'] = '<div align="center"><button onclick="arquivos(\''.$ped[3].'\')"><img src="../../img/folder.png" width="20" height="20"></button></div>';
    $cont['export'] = '<div align="center"><button onclick="exportar(\''.$ped[3].'\')"><img src="../../img/export.png" width="20" height="20"></button></div>';
    $cont['del'] = '<div align="center"><button onclick="remover_img(\''.$ped[3].'\')"><img src="../../img/delete.png" width="20" height="20"></button></div>';
  }



  $tabela->item($cont);
  $cnt++;
}

$tabela->fimtable();
echo '</div><br>';
?>
