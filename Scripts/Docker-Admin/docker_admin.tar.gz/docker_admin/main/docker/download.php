<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
session_cache_limiter('');
session_name('filemanager');
session_start();

$file = $_GET['file'];
header('Content-Type: application/octet-stream');
header("Content-Transfer-Encoding: Binary");
header("Content-disposition: attachment; filename=\"" . basename($file) . "\"");
readfile(PROJETO . '/images/' . $_SESSION['imagem_id'] . '/' . $file);
?>
