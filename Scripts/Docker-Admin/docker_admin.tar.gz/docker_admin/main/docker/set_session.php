<?php
session_cache_limiter('');
session_name('filemanager');
session_start();
$_SESSION['message'] = $_GET['message'];
$_SESSION['status'] = $_GET['status'];

?>
