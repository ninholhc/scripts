<?php
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
include "menu.php";

if(isset($_GET['appopen'])){
	switch ($_GET['appopen']) {
			case 5:
	        if(isset($_GET['dir'])){
						echo "<script language='javascript'>carregar('arq_sftp.php?p=" . $_GET['dir'] . "');</script>";
					}
					if(isset($_GET['ren'])){
						echo "<script language='javascript'>carregar('arq_sftp.php?p=" . $_GET['p'] . "&ren=" . $_GET['ren'] . "&to=" . $_GET['to'] . "');</script>";
						exit;
					}
					if(isset($_GET['new'])){
						echo "<script language='javascript'>carregar('arq_sftp.php?p=" . $_GET['p'] . "&new=" . $_GET['new'] . "');</script>";
						exit;
					}
					if(isset($_GET['p'])){
						echo "<script language='javascript'>carregar('arq_sftp.php?p=" . $_GET['p'] . "');</script>";
					}else{
						echo "<script language='javascript'>carregar('arq_sftp.php?p=');</script>";
					}
	        break;
	}
}

?>
