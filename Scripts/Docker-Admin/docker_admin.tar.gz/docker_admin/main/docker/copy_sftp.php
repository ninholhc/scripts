<?php
require_once(dirname(__FILE__) . '/../../conf/config.php');
session_cache_limiter('');
session_name('filemanager');
session_start();

function xcopy($src, $dest) {
    foreach (scandir($src) as $file) {
        if (!is_readable($src . '/' . $file)) continue;
        if (is_dir($src .'/' . $file) && ($file != '.') && ($file != '..') ) {
            mkdir($dest . '/' . $file);
            xcopy($src . '/' . $file, $dest . '/' . $file);
        } else {
            copy($src . '/' . $file, $dest . '/' . $file);
        }
    }
    return true;
}

function deleteDir($dirPath) {
    if (! is_dir($dirPath)) {
        throw new InvalidArgumentException("$dirPath não é um diretório");
    }
    if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
        $dirPath .= '/';
    }
    $files = glob($dirPath . '*', GLOB_MARK);
    foreach ($files as $file) {
        if (is_dir($file)) {
            deleteDir($file);
        } else {
            unlink($file);
        }
    }
    rmdir($dirPath);
    return true;
}

if(isset($_POST['finish'])){
  if (!is_dir($_POST['copy_to'])){
    if (!mkdir($_POST['copy_to'], 0775)){
      $_SESSION['message'] = "Diretorio ". $_POST['copy_to'] . " não existe e não foi possivel criá-lo" ;
      $_SESSION['status'] = "alert";
      header('Location: ../index.php?appopen=5');
      exit();
    }
  }
  $erro = 0;
  foreach ($_POST['file'] as $key => $value) {

      if(is_dir(PROJETO . '/sftp/' . $_GET['docker'] . '/' . $_GET['p'] . '/' . $value)){
        if(!xcopy(PROJETO . '/sftp/' . $_GET['docker']. '/' . $_GET['p'] . '/' . $value, $_POST['copy_to'])){
          $erro++;
          $msg = 'Falha ao copiar diretorio!';
        }
      }
      if(is_file(PROJETO . '/sftp/' . $_GET['docker'] . '/' . $_GET['p'] . '/' . $value)){
        if(!copy(PROJETO . '/sftp/' . $_GET['docker']. '/' . $_GET['p'] . '/' . $value,$_POST['copy_to'] . '/' . $value)){
          $erro++;
          $msg = 'Falha ao copiar arquivo!';
        }
      }
      if($_POST['move'] == '1'){
        if(is_dir(PROJETO . '/sftp/' . $_GET['docker'] . '/' . $_GET['p'] . '/' . $value)){
          deleteDir(PROJETO . '/sftp/' . $_GET['docker'] . '/' . $_GET['p'] . '/' . $value);
        }else{
          unlink(PROJETO . '/sftp/' . $_GET['docker'] . '/' . $_GET['p'] . '/' . $value);
        }

      }
  }

  if($erro > 0){
    $_SESSION['message'] = "Falha ao copiar arquivos!";
    $_SESSION['status'] = "error";
  }else{
    $_SESSION['message'] = "Arquivos e diretórios selecionados copiados!";
    $_SESSION['status'] = "ok";
  }
  header('Location: ../index.php?appopen=5&p='.$_GET['p'].'');
  exit();

}

?>
<div id="clear">
  <script type="text/javascript">
    const elements = document.getElementsByClassName("message error");
    elements[0].parentNode.removeChild(elements[0]);
    const elem = document.getElementsById("clear");
    elem[0].parentNode.removeChild(elem[0]);
  </script>
</div>
<div class="path">
    <p><b>Copiando</b></p>
    <form action="" method="post" id="copy">
        <input type="hidden" name="p" value="<?php if ($_GET['p'] == '/'){echo PATH;}else{echo PATH . '/' . $_GET['p'];} ?>">
        <input type="hidden" name="finish" value="1">
          <?php
          $reg = count($_POST['file']);
          if($reg > 1){
            echo '<p class="break-word">Arquivos:';
          }else{
            echo '<p class="break-word">Arquivo:';
          }
          $cont = 1;
          foreach ($_POST['file'] as $key => $value) {
            $cont++;
            if($cont > $reg){
              echo '<b>' . $value . '</b> ';
            }else{
              echo '<b>' . $value . '</b>, ';
            }
          }
          foreach($_POST['file'] as $key => $value){
            echo '<input type="hidden" name="file[]" value="'.$value.'">';
          }
           ?>
        </b></p>
        <p class="break-word">Caminho do arquivo: <?php if ($_GET['p'] == '/'){echo PROJETO . '/sftp/' . $_GET['docker'];}else{echo PROJETO . '/sftp/' . $_GET['docker'] . '/' . $_GET['p'];} ?><br>
        <p>Destino do arquivo:<input name="copy_to" id="inp_copy_to" value="<?php echo PROJETO . '/sftp/' . $_GET['docker']; ?>" size="50"></p>
        <p><label><input type="checkbox" name="move" value="1"> Mover</label></p>
        <p>
            <b><i class="icon-apply"></i><input type="submit" name="copy" formaction="copy_sftp.php?p=<?php echo $_GET['p'] ?>" value="Copiar"/> &nbsp;
            <a href="javascript:$('#conteudo').load(carregar('src/arq_sftp.php?p=<?php echo $_GET['p']; ?>'))"><i class="icon-cancel"></i> <input type="button" value="Cancelar"/></a></b>
        </p>
    </form>
</div>
