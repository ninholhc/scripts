<?php
define("PATH", "/var/www/html");
define("PROJETO", PATH."/docker_admin");
define("URL_PROJ", "http://localhost/docker_admin");
define("SIS", "/docker_admin");
define("MAIN", "/docker_admin/main");
?>
